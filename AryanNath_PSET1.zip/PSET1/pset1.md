A. Implement 1D Convolution in Python (no libraries)

    1.Without using for loops 

B. Implement 2D Convolution in Python (no libraries)

    2. Vectorisation, no for loops

    3. Using FFT 

C. Find Fast implementations on net (python, C or any other language) 

    4. Implement or At least Run it

D. Find implementation of convolution in tensor flow or PyTorch 

    5. Get the source code (from GitHub) and explain the CPU version

    Bonus explain the GPU version

You should have large 1D/2D signals and filters to play with. To see the difference in runtime of different methods above. These could be signals or images like triangle, gratings or possibly random inputs.

Result for 1-4 should be the error between your method and say np.convolve (with same input) and the RUNTIME for your method and np.convolve.

5 should be source code commented by you.